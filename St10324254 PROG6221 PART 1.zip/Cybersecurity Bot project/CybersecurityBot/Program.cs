﻿using System;
using System.Media;
using System.Threading;

namespace CybersecurityBot { 
class Program
{
    static void Main(string[] args)
    {
 
        PlayWelcomeSound();
        
        
        ShowAsciiArt();

      
        string name = GetUserName();
        WelcomeUser(name);

        
        while (true)
        {
            string query = GetUserQuery(name);
            HandleQuery(query, name);

            // Ask if user wants to continue
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\nDo you want to ask another question? (yes/no): ");
            Console.ResetColor();

            string continueChoice = Console.ReadLine().ToLower();
            if (continueChoice != "yes")
            {
                PrintWithColor("\nThank you for using the Cybersecurity Awareness Bot! Stay safe online!", ConsoleColor.Green);
                break;
            }
        }
    }

   // Voice greeting implemented
    public static void PlayWelcomeSound()
    {
        try
        {
            SoundPlayer player = new SoundPlayer("welcome.wav");
           
            player.PlaySync();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Audio error: " + ex.Message);
        }
    }

   //The ASCII art display
    static void ShowAsciiArt()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine(@"
       ___     _  _   _                                                                 _      _       _  _             ___             _     
  / __|   | || | | |__     ___      _ _    ___     ___     __     _  _      _ _    (_)    | |_    | || |    o O O  | _ )    ___    | |_   
 | (__     \_, | | '_ \   / -_)    | '_|  (_-<    / -_)   / _|   | +| |    | '_|   | |    |  _|    \_, |   o       | _ \   / _ \   |  _|  
  \___|   _|__/  |_.__/   \___|   _|_|_   /__/_   \___|   \__|_   \_,_|   _|_|_   _|_|_   _\__|   _|__/   TS__[O]  |___/   \___/   _\__|  
_|""""""""""|_| """"""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_|""""""""""|_| """"""""| {======|_|""""""""""|_|""""""""""|_|""""""""""| 
""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'""`-0-0-'./o--000'""`-0-0-'""`-0-0-'""`-0-0-' 
        ");
        Console.ResetColor();
        Thread.Sleep(1000); // Pause for effect
    }

  
    static string GetUserName()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("\nEnter your name: ");
        Console.ResetColor();

        string name;
        while (true)
        {
            name = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(name))
                break;
            PrintWithColor("Please enter a valid name!", ConsoleColor.Red);
        }
        return name;
    }

    // 4. Personalized welcome
    static void WelcomeUser(string name)
    {
        PrintWithColor($"\nWelcome, {name}!", ConsoleColor.Green);
        PrintWithColor("I'm here to help you stay safe online.", ConsoleColor.Cyan);
        PrintWithColor("You can ask me about:", ConsoleColor.Yellow);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("- 'Phishing' (How to spot fake emails)");
        Console.WriteLine("- 'Passwords' (Creating strong passwords)");
        Console.WriteLine("- 'Browsing' (Safe internet practices)");
        Console.WriteLine("- 'Malware' (Avoiding viruses)");
        Console.WriteLine("----------------------------------------");
    }

    // 5. Handle user queries
    static void HandleQuery(string query, string name)
    {
        switch (query.ToLower())
        {
            case "phishing":
                PrintWithColor($"\n{name}, Here is how to spot phishing attacks:", ConsoleColor.Green);
                Console.WriteLine("- Check sender email addresses");
                Console.WriteLine("- Look for spelling mistakes");
                Console.WriteLine("- Never click suspicious links");
                Console.WriteLine("- When in doubt, contact the company directly");
                break;

            case "passwords":
                PrintWithColor($"\n{name}, Here are strong password tips:", ConsoleColor.Green);
                Console.WriteLine("- Use at least 12 characters");
                Console.WriteLine("- Mix letters, numbers, and symbols");
                Console.WriteLine("- Avoid common words or birthdays");
                Console.WriteLine("- Use a password manager");
                break;

            case "browsing":
                PrintWithColor($"\n{name}, safe browsing practices:", ConsoleColor.Green);
                Console.WriteLine("- Look for 'https://' and padlock icons");
                Console.WriteLine("- Don't enter personal info on public Wi-Fi");
                Console.WriteLine("- Use ad-blockers to avoid malicious ads");
                Console.WriteLine("- Keep your browser updated");
                break;

            case "malware":
                PrintWithColor($"\n{name}, malware prevention:", ConsoleColor.Green);
                Console.WriteLine("- Don't download from untrusted sites");
                Console.WriteLine("- Keep your antivirus software updated");
                Console.WriteLine("- Be careful with email attachments");
                Console.WriteLine("- It is important to regularly back up your data");
                break;

            default:
                PrintWithColor($"\nI'm not sure about that, {name}. Try asking about:", ConsoleColor.Red);
                Console.WriteLine("- 'Phishing'");
                Console.WriteLine("- 'Passwords'");
                Console.WriteLine("- 'Browsing'");
                Console.WriteLine("- 'Malware'");
                break;
        }
    }

    // Gets and validates user query
    static string GetUserQuery(string name)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write($"\n{name}, what would you like to know about? ");
        Console.ResetColor();

        string input;
        while (true)
        {
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
                return input;

            PrintWithColor("Please enter a valid question!", ConsoleColor.Red);
        }
    }

    // Helper method for colored text
    static void PrintWithColor(string text, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(text);
        Console.ResetColor();
    }
}
}